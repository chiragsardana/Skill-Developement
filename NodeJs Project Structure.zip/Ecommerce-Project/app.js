const express = require('express');

var app = express();
app.use(express.static("public")); // I am Using a Middleware
require("dotenv").config();
app.use(express.json()); // {key:value}
app.use(express.urlencoded()); // key=value&key=value

app.get('/', function (req, res) {
    res.send('Hello Chirag Sardana Sardana_boy_kanu');
})
  
const server = app.listen(process.env.PORT || 3000, (err) => {
    if (err) {
      console.log("App Crash ", err);
    } else {
      console.log("Server Started... ", server.address().port);
    }
  });